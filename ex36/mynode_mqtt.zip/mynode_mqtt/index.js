var mqtt = require("mqtt");
var host = "localhost";
var port = 9001;

var client = mqtt.connect("ws://" + host + ":" + port);

var CommandTopic = "control/leds/";
var ResultTopic = "control/results/leds/";

client.on("connect", function () {
    console.log("Connected to the MQTT server");
    var topicFilters = Array();
    for (i = 1; i < 4; i++) {
        topicFilters.push(CommandTopic + i);
    }
    client.subscribe(topicFilters);
});
 
client.on('message', function (topic, message) {
    // message is Buffer 
    var payloadString = message.toString();
    console.log("Message arrived for topic: " + topic + ", with the following payload: " + payloadString);
    if (!topic.startsWith(CommandTopic)) {
        return;
    }
    var ledNumber = topic.replace(CommandTopic, "");
    var payload = JSON.parse(payloadString);
    if (ledNumber && payload.Color) {
        console.log("Changed LED #" + ledNumber + " to " + payload.Color);
    }
    var resultMessagePayload = {
        "Color": payload.Color
    };
    resultMessagePayloadString = JSON.stringify(resultMessagePayload);

    client.publish(ResultTopic + ledNumber, resultMessagePayloadString);
});
